import xbmc
import xbmcgui
import xbmcaddon
import os
import urllib.parse
import urllib.request
import shutil

ADDON = xbmcaddon.Addon()
ADDON_NAME = ADDON.getAddonInfo('name')

def get_filename_from_url(url):
    try:
        path = urllib.parse.urlparse(url).path
        filename = os.path.basename(path)
        filename = urllib.parse.unquote(filename)
        
        # Basic sanitization
        keepcharacters = (' ','.','_','-','(',')','[',']')
        filename = "".join(c for c in filename if c.isalnum() or c in keepcharacters).rstrip()
        
        if not filename or len(filename) < 3:
            return "video_descargado.mkv"
        return filename
    except:
        return "video_descargado.mkv"

def check_disk_space(path, required_size):
    try:
        total, used, free = shutil.disk_usage(path)
        return free > required_size
    except:
        return True # Fail open if we can't check

def resolve_url(url):
    # Placeholder for future plugin:// resolution
    return url

def download_video(url, download_folder, silent=False):
    """
    Downloads a video from url to download_folder.
    silent: If True, suppresses some dialogs (useful for auto-download), 
            but we still might want progress or notifications.
            For now, we'll keep the progress bar as it's non-blocking in a thread usually.
    """
    filename = get_filename_from_url(url)
    dest_path = os.path.join(download_folder, filename)
    
    # Check if file exists? For now overwrite or let it be.
    
    p_dialog = None
    try:
        if not silent:
            p_dialog = xbmcgui.DialogProgressBG()
            p_dialog.create(ADDON_NAME, "Conectando...")
        
        xbmcgui.Dialog().notification(ADDON_NAME, f"Iniciando descarga en: {download_folder}", xbmcgui.NOTIFICATION_INFO, 5000)
        
        req = urllib.request.Request(url, headers={'User-Agent': 'Mozilla/5.0'})
        response = urllib.request.urlopen(req, timeout=30)
        
        total_size = int(response.info().get('Content-Length', 0).strip())
        
        if total_size > 0:
            if not check_disk_space(download_folder, total_size):
                if p_dialog: p_dialog.close()
                xbmcgui.Dialog().notification(ADDON_NAME, "Espacio insuficiente", xbmcgui.NOTIFICATION_ERROR, 5000)
                return

        block_size = 1024 * 1024 
        downloaded = 0
        
        with open(dest_path, 'wb') as f:
            while True:
                chunk = response.read(block_size)
                if not chunk: break
                f.write(chunk)
                downloaded += len(chunk)
                
                if p_dialog:
                    if total_size > 0:
                        percent = int((downloaded / total_size) * 100)
                        p_dialog.update(percent, message=f"Descargando: {percent}%")
                    else:
                        p_dialog.update(0, message=f"Descargando: {downloaded // (1024*1024)} MB")
                    
                    if p_dialog.isFinished(): 
                        break
        
        if p_dialog: p_dialog.close()
        xbmcgui.Dialog().notification(ADDON_NAME, "Descarga completada", xbmcgui.NOTIFICATION_INFO, 5000)

    except Exception as e:
        if p_dialog: p_dialog.close()
        xbmc.log(f"[{ADDON_NAME}] ERROR: {str(e)}", xbmc.LOGERROR)
        xbmcgui.Dialog().notification(ADDON_NAME, f"Error: {str(e)}", xbmc.NOTIFICATION_ERROR, 5000)
