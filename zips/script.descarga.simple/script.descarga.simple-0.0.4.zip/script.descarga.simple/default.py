import xbmc
import xbmcgui
import xbmcaddon
import os
import sys
import threading

# Add resources/lib to python path
cwd = os.path.dirname(os.path.abspath(__file__))
lib_path = os.path.join(cwd, 'resources', 'lib')
sys.path.append(lib_path)

import downloader

ADDON = xbmcaddon.Addon()
ADDON_NAME = ADDON.getAddonInfo('name')

def main():
    player = xbmc.Player()
    if not player.isPlaying():
        xbmcgui.Dialog().notification(ADDON_NAME, "Nada en reproducción", xbmcgui.NOTIFICATION_WARNING)
        return

    raw_url = player.getPlayingFile()
    url = downloader.resolve_url(raw_url)
    
    xbmc.log(f"[{ADDON_NAME}] URL Detectada: {url}", xbmc.LOGINFO)

    # Allow http, https, ftp
    if not url.startswith("http") and not url.startswith("ftp"):
        xbmcgui.Dialog().ok(ADDON_NAME, f"URL no soportada:\n{url[:50]}...")
        return

    download_folder = ADDON.getSetting('download_path')
    if not download_folder:
        ADDON.openSettings()
        download_folder = ADDON.getSetting('download_path')
        if not download_folder: return

    filename = downloader.get_filename_from_url(url)
    
    if xbmcgui.Dialog().yesno(ADDON_NAME, f"¿Descargar?\n{filename}"):
        t = threading.Thread(target=downloader.download_video, args=(url, download_folder))
        t.start()

if __name__ == '__main__':
    main()
